//
//  internApp.swift
//  intern
//
//  Created by Nikhil James on 24/05/24.
//

import SwiftUI

@main
struct internApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
